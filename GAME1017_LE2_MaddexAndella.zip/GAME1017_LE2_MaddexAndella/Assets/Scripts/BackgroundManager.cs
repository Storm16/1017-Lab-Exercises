using UnityEngine;

public class BackgroundManager : MonoBehaviour
{
    [SerializeField] private GameObject backgroundPrefab;
    [SerializeField] private Camera cam;

    [SerializeField] private float xBuffer = 3;

    private GameObject backgroundGO;

    private void Start()
    {
        cam = Camera.main;

        backgroundGO = Instantiate(backgroundPrefab, transform);
        backgroundGO.transform.Translate(new Vector3 (10.0f, 0.0f, 0.0f));
    }

    private void Update()
    {
        if (/*background Start position*/cam.transform.parent.position.x + (cam.orthographicSize * cam.aspect * 2) + xBuffer >= backgroundGO.GetComponent<Renderer>().bounds.size.x)
            Debug.Log("End Reached");

        // Spawn new background object at position @ background startPos + backgroundGO.GetComponent<Renderer>().bounds.size.x
    }
}
