using UnityEngine;

public enum GameState
{
    InMenu,

    InGame,

    GameOver,
}

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public GameState CurrentGameState { get; private set; }
    public SoundManager SoundManager;
    private PlayerController player;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void Start()
    {
        CurrentGameState = GameState.InMenu;

        player = FindFirstObjectByType<PlayerController>();
    }

    public void PlayGame()
    {
        SetGameState(GameState.InGame);
    }

    public void GameOver()
    {
        SetGameState(GameState.GameOver);
    }

    public void RestartGame()
    {
        player.ResetPlayer();
        SetGameState(GameState.InMenu);
    }

    public void SetGameState(GameState state)
    {
        CurrentGameState = state;
    }
}
