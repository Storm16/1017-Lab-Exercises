using UnityEngine;

/// <summary>
/// A script that handles player movement.
/// In it's currwnt state it only moves the player laterally in the positive x.
/// </summary>

public class PlayerController : MonoBehaviour
{
    // Edit for source control
    [SerializeField] private float speed;

    private Vector3 startPosition;

    private void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        if (GameManager.Instance.CurrentGameState != GameState.InGame) return;

        // Calculate the distance we should move the object on a per frame basis. -> Make it frame rate independent.
        float distancePerFrame = speed * Time.deltaTime;

        // Move the attached game object in the x coordinate.
        transform.Translate(distancePerFrame, 0, 0);
    }

    public void ResetPlayer()
    {
        transform.position = startPosition;
    }

    // Considerations: 
    // What happens if the user enters a negative speed in the inspector? How can we guard against that?
    // Hint: Math.ABS or [range]
}
