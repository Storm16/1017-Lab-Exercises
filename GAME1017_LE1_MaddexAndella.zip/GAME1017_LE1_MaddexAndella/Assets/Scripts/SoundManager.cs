using UnityEngine;

/// <summary>
///A singleten class that handles the sound for the game./
/// </summary>

public class SoundManager : MonoBehaviour
{
    [SerializeField] private AudioSource musicSource, sfxSource;

    private static SoundManager instance;
    public static SoundManager Instance

    {
        get
        {
            if (instance == null)
            {
                // checxk if instance exsists in the scene
                instance = FindFirstObjectByType<SoundManager>();

                // create a game object with Singleton
                if (instance == null)
                {
                    GameObject soundManager = new GameObject(nameof(SoundManager));
                    soundManager.AddComponent<SoundManager>();
                }


            }

            return instance;
        }
    }

    private void Awake()
    {
        // If an instance already exists and it's not this, destroy this

        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;


        DontDestroyOnLoad(gameObject);
    }

    [ContextMenu("Change Music Volume")]
    public void ChangeMusicVolume(float newVolume)
    {
        // mixer.GetGroup("Music").setVolume;
        musicSource.volume = newVolume;
    }

    [ContextMenu("Change SFX Volume")]
    public void ChangeSFXVolume(float newVolume)
    {
        sfxSource.volume = newVolume;
    }
}
